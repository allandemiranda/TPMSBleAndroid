package lu.allandemiranda.tpms.model;

public record ManofactureData(String mac, int rssi, byte[] data) {
}
