package lu.allandemiranda.tpms.util;

import java.util.Arrays;

public final class TpmsDecoder {

    public static TpmsDecoder.TPMS decode(byte[] data) {
        if (data == null || data.length < 12) {
            UiLogger.log("Dados de fabricante inválidos ou muito curtos." + Arrays.toString(data));
            return null;
        }

        int length = data[0] & 0xFF;
        if (length != data.length) {
            UiLogger.log("Tamanho inesperado do pacote: " + length + " bytes, mas recebido: " + data.length);
            return null;
        }

        int temperature = data[1];
        int pressureRaw = ((data[2] & 0xFF) << 8) | (data[3] & 0xFF);

        return new TpmsDecoder.TPMS(temperature, pressureRaw);
    }

    public record TPMS(int temperature, int pressure) {

    }

}
