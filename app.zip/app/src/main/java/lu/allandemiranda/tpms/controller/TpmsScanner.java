package lu.allandemiranda.tpms.controller;

import android.content.Context;

import java.util.List;

import lu.allandemiranda.tpms.model.ManofactureData;
import lu.allandemiranda.tpms.model.Tpms;
import lu.allandemiranda.tpms.service.BleScanner;
import lu.allandemiranda.tpms.util.TpmsDecoder;
import lu.allandemiranda.tpms.util.UiLogger;

public final class TpmsScanner {

    private final BleScanner bleScanner;

    public TpmsScanner(Context context) {
        this.bleScanner = new BleScanner(context);
    }

    public Tpms[] getTpms(String macFront, String macRear) {
        List<ManofactureData> mds = bleScanner.getManufacturerData(2000);
        Tpms[] moto = new Tpms[]{null, null};

        for (int i = 0; i < mds.size(); i++) {
            if (moto[0] == null && mds.get(i).mac().equals(macFront)) {
                TpmsDecoder.TPMS decode = TpmsDecoder.decode(mds.get(i).data());
                if (decode != null) {
                    moto[0] = new Tpms(macFront, decode.pressure(), decode.temperature(), mds.get(i).rssi());
                } else {
                    UiLogger.log("Error ao decodificar " + macFront);
                }
            } else if (moto[1] == null && mds.get(i).mac().equals(macRear)) {
                TpmsDecoder.TPMS decode = TpmsDecoder.decode(mds.get(i).data());
                if (decode != null) {
                    moto[1] = new Tpms(macRear, decode.pressure(), decode.temperature(), mds.get(i).rssi());
                } else {
                    UiLogger.log("Error ao decodificar " + macRear);
                }
            }
        }
        return moto;
    }
}
