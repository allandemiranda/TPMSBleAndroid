package lu.allandemiranda.tpms.view;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import lu.allandemiranda.tpms.R;
import lu.allandemiranda.tpms.config.Config;
import lu.allandemiranda.tpms.controller.TpmsScanner;
import lu.allandemiranda.tpms.model.TireState;
import lu.allandemiranda.tpms.model.Tpms;
import lu.allandemiranda.tpms.util.NotificationHelper;
import lu.allandemiranda.tpms.util.UiLogger;
import lu.allandemiranda.tpms.util.UnitConverter;

public class MainActivity extends AppCompatActivity implements UiLogger.Sink {

    private static final int REQ_PERMS = 42;
    private final TireState frontState = new TireState();
    private final TireState rearState = new TireState();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TpmsScanner tpmsScanner;
    private TextView tvFrontTime, tvFrontPressure, tvFrontTemp, tvFrontRssi;
    private ImageView dotFront;
    private TextView tvRearTime, tvRearPressure, tvRearTemp, tvRearRssi;
    private ImageView dotRear;
    private final Runnable repetitiveTask = new Runnable() {
        @Override
        public void run() {
            Tpms[] tpms = tpmsScanner.getTpms(Config.FRONT_MAC, Config.REAR_MAC);

            if (tpms[0] != null) {
                frontState.setLastUpdate(LocalDateTime.now());
                frontState.setRssi(tpms[0].rssi());
                frontState.setPressureKpa(UnitConverter.pressureTpmsToKpa(tpms[0].pressure()));
                frontState.setTemperatureC(tpms[0].temperature());

                tvFrontTime.setText(frontState.getLastUpdate().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
                tvFrontTemp.setText(String.format(Locale.US, "%02d°C", frontState.getTemperatureC()));
                double kpa = UnitConverter.pressureTpmsToKpa(frontState.getPressureKpa());
                double psi = UnitConverter.kpaToPsi(kpa);
                tvFrontPressure.setText(String.format(Locale.US, "%03d kPa (%.1f PSI)", (int) Math.round(kpa), psi));
                tvFrontRssi.setText(String.format(Locale.US, "-%d dBm", frontState.getRssi()));
            }
            if (tpms[1] != null) {
                rearState.setLastUpdate(LocalDateTime.now());
                rearState.setRssi(tpms[1].rssi());
                rearState.setPressureKpa(UnitConverter.pressureTpmsToKpa(tpms[1].pressure()));
                rearState.setTemperatureC(tpms[1].temperature());

                tvRearTime.setText(rearState.getLastUpdate().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
                tvRearTemp.setText(String.format(Locale.US, "%02d°C", rearState.getTemperatureC()));
                double kpa = UnitConverter.pressureTpmsToKpa(rearState.getPressureKpa());
                double psi = UnitConverter.kpaToPsi(kpa);
                tvRearPressure.setText(String.format(Locale.US, "%03d kPa (%.1f PSI)", (int) Math.round(kpa), psi));
                tvRearRssi.setText(String.format(Locale.US, "-%d dBm", rearState.getRssi()));
            }

            int frontStateColor = frontState.getColor(Config.FRONT_MIN_KPA, Config.FRONT_MAX_KPA);
            if (frontStateColor != dotFront.getSolidColor()) {
                dotFront.setColorFilter(ContextCompat.getColor(getMainActivity(), frontStateColor));
                if (R.color.yellow == frontStateColor) {
                    NotificationHelper.notifySignalLost(getMainActivity(), true);
                    UiLogger.log("FRONT SIGNAL LOST");
                } else if (R.color.orange == frontStateColor && frontState.getPressureKpa() < Config.FRONT_MIN_KPA) {
                    NotificationHelper.notifyPressure(getMainActivity(), true, frontState.getPressureKpa(), Config.FRONT_MIN_KPA, Config.FRONT_MAX_KPA);
                } else if (R.color.orange == frontStateColor && frontState.getPressureKpa() > Config.FRONT_MAX_KPA) {
                    NotificationHelper.notifyPressure(getMainActivity(), true, frontState.getPressureKpa(), Config.FRONT_MIN_KPA, Config.FRONT_MAX_KPA);
                }
            }

            int rearStateColor = rearState.getColor(Config.REAR_MIN_KPA, Config.REAR_MAX_KPA);
            if (rearStateColor != dotRear.getSolidColor()) {
                dotRear.setColorFilter(ContextCompat.getColor(getMainActivity(), rearStateColor));
                if (R.color.yellow == rearStateColor) {
                    NotificationHelper.notifySignalLost(getMainActivity(), true);
                    UiLogger.log("REAR SIGNAL LOST");
                } else if (R.color.orange == rearStateColor && rearState.getPressureKpa() < Config.REAR_MIN_KPA) {
                    NotificationHelper.notifyPressure(getMainActivity(), true, rearState.getPressureKpa(), Config.REAR_MIN_KPA, Config.REAR_MAX_KPA);
                } else if (R.color.orange == rearStateColor && rearState.getPressureKpa() > Config.REAR_MAX_KPA) {
                    NotificationHelper.notifyPressure(getMainActivity(), true, rearState.getPressureKpa(), Config.REAR_MIN_KPA, Config.REAR_MAX_KPA);
                }
            }

            handler.postDelayed(this, 1000);
        }
    };
    private TextView tvDebug;

    private boolean checkBleSupport() {
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (bm == null) return false;
        BluetoothAdapter adapter = bm.getAdapter();
        return adapter != null && adapter.isEnabled();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UiLogger.setSink(this);
        View root = findViewById(R.id.rootLayout);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets sys = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(sys.left, sys.top, sys.right, sys.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        tvDebug = findViewById(R.id.tvDebug);
        if (Config.DEBUG_UI) {
            findViewById(R.id.debugScroll).setVisibility(View.VISIBLE);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        findViewById(R.id.btnInfo).setOnClickListener(v -> startActivity(new Intent(this, lu.allandemiranda.tpms.view.InfoActivity.class)));

        tvFrontTime = findViewById(R.id.tvFrontTime);
        tvFrontPressure = findViewById(R.id.tvFrontPressure);
        tvFrontTemp = findViewById(R.id.tvFrontTemp);
        tvFrontRssi = findViewById(R.id.tvFrontRssi);
        dotFront = findViewById(R.id.dotFront);

        tvRearTime = findViewById(R.id.tvRearTime);
        tvRearPressure = findViewById(R.id.tvRearPressure);
        tvRearTemp = findViewById(R.id.tvRearTemp);
        tvRearRssi = findViewById(R.id.tvRearRssi);
        dotRear = findViewById(R.id.dotRear);

        this.tpmsScanner = new TpmsScanner(this);

        if (!checkBleSupport()) {
            log("BLE não suportado ou Bluetooth desligado.");
            return;
        }

        requestAllPermissions();

        handler.post(repetitiveTask);
    }

    private MainActivity getMainActivity() {
        return this;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        UiLogger.setSink(null);
        handler.removeCallbacks(repetitiveTask);
    }

    @Override
    public void log(String msg) {
        if (!Config.DEBUG_UI) return;

        String time = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        tvDebug.append(time + "  " + msg + "\n");

        ((ScrollView) tvDebug.getParent()).post(() -> ((ScrollView) tvDebug.getParent()).fullScroll(View.FOCUS_DOWN));
    }

    private void requestAllPermissions() {
        List<String> permissions = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!permissions.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toArray(new String[0]), REQ_PERMS);
        } else {
            handler.post(repetitiveTask);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                handler.post(repetitiveTask);
            } else {
                Toast.makeText(this, "Permissões necessárias não concedidas.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
