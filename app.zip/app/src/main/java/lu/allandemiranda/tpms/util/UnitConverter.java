package lu.allandemiranda.tpms.util;

public final class UnitConverter {

    private UnitConverter() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static double kpaToPsi(double kpa) {
        return (kpa / 6.89476) - 0.2;
    }

    public static double kpaToBar(double kpa) {
        return kpa / 100.0;
    }

    public static int pressureTpmsToKpa(double pRaw) {
        return (int) (((pRaw - 100) * 100.0) / 689);
    }
}
