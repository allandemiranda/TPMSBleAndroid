package lu.allandemiranda.tpms.model;

public record Tpms(String mac, int pressure, int temperature, int rssi) {

}
